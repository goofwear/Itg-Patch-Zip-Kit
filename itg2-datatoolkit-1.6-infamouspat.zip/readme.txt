ITG2 data file encryption toolkit
 copystraight 2008 infamouspat

 usages:
 ./itg2-encrypt data-extra.zip /mnt/hda5/data-extra.zip
 ./itg2-decrypt /mnt/hda5/data4.zip d4.zip

 ./itg2-patch-encrypt patch-custom.zip /mnt/hda3/patch/patch.zip
 ./itg2-patch-decrypt /mnt/hda3/patch/patch.zip patch-dec.zip


 DISCLAIMER:
  I'm keeping this short and simple.  This gives you full control over
 your precious Boxor, so watch what you're doing.  I, nor Roxor Tech support or
 any affiliates are responsible for what happens to your little toy.
 
 Q) what the hell are these?
  itg2-encrypt/decrypt are two programs that work directly with the dongle
 and filesystem to encrypt and decrypt the zip files stored on the hda5 
 partition of your typical ITG2 drive.
  These programs have been laying around my computer collecting dust for 
 a good while and I guess this is an okay time to release them to the public.
 
 Q) so how exactly do I use these?

 itg2-decrypt, itg2-encrypt:
  1) copy these 2 files to the root of your Slax USB jumpdrive
  2) throw everything you want to add to a single zip file and put that
   in the root of your USB jumpdrive as well.  When I say
  everything, if you're including Songs, this also means Cache too. ;-)
  3) follow the cmcm / Boxorroxors song adding guide
   (http://www.boxorroxors.net/tutorials.php?mode=view&t=195)
   and STOP after you mount your USB drive (mount /dev/sda1 /mnt/hi)
  4) execute this command: /mnt/hi/itg2-encrypt /mnt/hi/custom.zip /mnt/hda5/data-extra.zip
           data-extra.zip can really be named anything
  5) after encryption, execute this command: sync
  6) reboot the cabinet

 itg2-patch-decrypt, itg2-patch-encrypt:
  These two programs are basically static linux ports of the ITG2 patch
 decrypter and encrypter program found on boxorroxors.net.  The patch.zip
 file is found in /stats/patch/patch.zip (in Slax: /mnt/hda3/patch/patch.zip).
 
 Q) why would I want to use these over the Static.ini method?
  Up to you to answer that, though this would be more convenient than
 making a Static.ini file.  Once again, these are just programs that have been
 sitting around on my hard drive for the longest time and I figured they could
 be released.
 
 Q) what is itg2-keydump and itg2-static-decrypt?
  itg2-decrypt in the form of two seperate programs.

 Special thanks:
 the PressX LAAAAAb, GRIM.657, nevets933, Roxami & Co. (testers): would have not been 
 possible without you guys so you need to be thrown in here.
 
 Special NO thanks:
 Pocket Change, Park City mall: kicking me out for just suggesting the r21
 update then installing it a few weeks later.  You guys are awesome.
